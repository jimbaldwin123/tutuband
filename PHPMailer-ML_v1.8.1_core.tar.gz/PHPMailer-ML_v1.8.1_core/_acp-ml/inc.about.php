<?php
/*~ _acp-ml/inc.lists.php
.---------------------------------------------------------------------------.
|  Software: PHPMailer-ML - PHP mailing list                                |
|   Version: 1.8.1                                                          |
|   Contact: via sourceforge.net support pages (also www.codeworxtech.com)  |
|      Info: http://phpmailer.sourceforge.net                               |
|   Support: http://sourceforge.net/projects/phpmailer/                     |
| ------------------------------------------------------------------------- |
|    Author: Andy Prevost (project admininistrator)                         |
| Copyright (c) 2004-2009, Andy Prevost. All Rights Reserved.               |
| ------------------------------------------------------------------------- |
|   License: Distributed under the General Public License (GPL)             |
|            (http://www.gnu.org/licenses/gpl.html)                         |
| This program is distributed in the hope that it will be useful - WITHOUT  |
| ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or     |
| FITNESS FOR A PARTICULAR PURPOSE.                                         |
| ------------------------------------------------------------------------- |
| We offer a number of paid services (www.codeworxtech.com):                |
| - Web Hosting on highly optimized fast and secure servers                 |
| - Technology Consulting                                                   |
| - Oursourcing (highly qualified programmers and graphic designers)        |
'---------------------------------------------------------------------------'

/**
 * PHPMailer-ML - PHP mailing list manager
 * @package PHPMailer-ML
 * @author Andy Prevost
 * @copyright 2004 - 2009 Andy Prevost. All Rights Reserved.
 */

defined('_WRX') or die( _errorMsg('Restricted access') );

echo '<div align="center">';
echo '<br />';

?>
<style>
p {
  font: 12px Arial, Helvetica, sans-serif;
}
</style>
<div class="text" align="left" style="font-weight:normal;">
<p style="margin-top:0px;">Make your efforts count with rapid project
development from Worx International Inc. We are available for projects of any size.
<a style="text-decoration: underline;" href="http://www.worxware.com/" target="_blank">Contact us</a>
today for a quote!.</p>
<p>Thank you for downloading and using a Worx International Inc. product. We'd like to hear
from you and how you are using this version.</p>
<p>PHPMailer is the world's leading email transport class and downloaded an
average of more than 32,000 each month. In March 2009, PHPMailer was downloaded
more than 31,000 times -- that's an average of 1,000 downloads daily. Our thanks
to our new users and loyal users. We understand you have many choices available
to select from and we thank you for select our fast and stable tool for your
website and projects.</p>
<p>Credits:<br>
PHPMailer's original founder is Brent Matzelle. The current team is:<br>
Project Administrator: Andy Prevost (codeworxtech),
<a href="mailto:codeworxtech@users.sourceforge.net">
codeworxtech@users.sourceforge.net</a><br>
Author: Andy Prevost (codeworxtech) codeworxtech@users.sourceforge.net<br>
Author: Marcus Bointon (coolbru) <a href="mailto:coolbru@users.sourceforge.net">
coolbru@users.sourceforge.net</a></p>
<p>PHPMailer is used in many projects ranging from Open Source to commercial
packages. Our LGPL licensing terms are very flexible and allow for including
PHPMailer to enhance projects of all types. If you discover PHPMailer being used
in a project, please let us know about it.</p>
<p><strong>WHY USE OUR TOOLS &amp; WHAT&#39;S IN IT FOR YOU?</strong></p>
<p>A valid question. We're developers too. We've been writing software, primarily
for the internet, for more than 15 years. Along the way, there are two major things
that had tremendous impact of our company: PHP and Open Source. PHP is without doubt
the most popular platform for the internet. There has been more progress in this
area of technology because of Open Source software than in any other IT segment. We
have used many open source tools, some as learning tools, some as components in
projects we were working on. To us, it's not about popularity ... we're committed
to robust, stable, and efficient tools you can use to get your projects in your
user's hands quickly. So the shorter answer: what's in it for you? rapid development
and rapid deployment without fuss and with straight forward open source licensing.</p>
<table width="100%" cellpadding="5" style="border-collapse: collapse" border="1">
  <tr>
    <th><b>About Andy Prevost, AKA "codeworxtech".</b></th>
  </tr>
  <tr>
    <td width="100%" valign="top">
      <p><a href="http://www.worxware.com">www.worxware.com</a> for more information.<br>
      Web design, web applications, forms: <a href="http://www.worxstudio.com">WorxStudio.com</a><br />
      </p>
      <p>Our company, <strong>Worx International Inc.</strong>, is the publisher of several Open Source applications and developer tools as well as several commercial PHP applications. The Open Source applications are ttCMS and DCP Portal. The Open Source developer tools include QuickComponents (QuickSkin and QuickCache) and now PHPMailer.
      We have staff and offices in the United States, Caribbean, the Middle
      East, and our primary development center in Canada. Our company is represented by
      agents and resellers globally.</p>
      <p><strong>Worx International Inc.</strong> is at the forefront of developing PHP applications. Our staff are all Zend Certified university educated and experts at object oriented programming. While <strong>Worx International Inc.</strong> can handle any project from trouble shooting programs written by others all the way to finished mission-critical applications, we specialize in taking projects from inception all the way through to implementation - on budget, and on time. If you need help with your projects, we&#39;re the team to get it done right at a reasonable price.</p>
      <p>Over the years, there have been a number of tools that have been constant favorites in all of our projects. We have become the project administrators for most of these tools. We have also authored many projects.</p>
      <p>Our developer tools are all Open Source. Here&#39;s a brief description:</p>
      <ul>
        <li style="font-family: Arial, Helvetica, sans-serif; font-size: 13px"><span style="background-color: #FFFF00"><strong>PHPMailer</strong></span>. Originally authored by Brent Matzelle, PHPMailer is the leading "email transfer class" for PHP. PHPMailer is downloaded more than
        30000 times each and every month by developers looking for a fast, stable, simple email solution. We used it ourselves for years as our favorite tool. It&#39;s always been small (the entire footprint is
        less than 100 Kb), stable, and as complete a solution as you can find.
        Other tools are nowhere near as simple. Our thanks to Brent Matzelle for this superb tool - our commitment is to keep it lean, keep it focused, and compliant with standards. Visit the <a href="http://phpmailer.worxware.com/">PHPMailer website</a>.<br />
        Please note: <strong>all of our focus is now on the PHPMailer for PHP5.</strong><br />
        <span style="background-color: #FFFF00">PS. While you are at it, please visit our sponsor&#39;s sites, click on their ads.
        It helps offset some of our costs.</span><br />
        Want to help? We're looking for progressive developers to join our team of volunteer professionals working on PHPMailer. Our entire focus is on PHPMailer
        for PHP5. If you are interested, let us know.<br />
        <br />
        </li>
        <li style="font-family: Arial, Helvetica, sans-serif; font-size: 13px"><span style="background-color: #FFFF00"><strong>PHPMailer-FE</strong></span>.
        PHPMailer-FE is project originally
        conceived for Worx International Inc. projects, the public release was
        enhanced to be API compatible with Formmail.pl and Formmail.php and has
        many of the features of the Perl script Soupermail. PHPMailer-FE has
        evolved to also support Flash forms and many users report success using
        it in Ajax environments. PHPMailer-FE works only with $_POST data and
        will stop processing when any $_GET (URL injection) data is found &ndash; a terrific
        security feature. We also include data sanitizing to prevent forms being
        used for SQL injection, script hacks, etc. Other features include:
        plugin capabilities, individual form configurations, text &amp; HTML email
        form submission and custom failure and success redirection. Visit the <a href="http://phpmailer.worxware.com/">PHPMailer-FE website</a>.<br />
        <br />
        </li>
        <li style="font-family: Arial, Helvetica, sans-serif; font-size: 13px"><span style="background-color: #FFFF00"><strong>PHPMailer-ML</strong></span>.
        PHPMailer-ML is project originally conceived as a sample application to
        showcase how PHPMailer could be used in a database and application
        environment. PHPMailer-ML is now a robust Mailing List and eMessaging
        platform that supports multiple mailing lists, several WYSIWYG editors,
        message preview, credit/edit, and send capabilities. PHPMailer-ML now
        supports both PHPMailer-Lite and PHPMailer. Visit the <a href="http://phpmailer.worxware.com/">PHPMailer-ML website</a>.<br />
        <br />
        </li>
        <li><strong><span style="background-color: #FFFF00">QuickCache</span></strong>. Originally authored by Jean Pierre Deckers as jpCache, QuickCache is an HTTP OpCode caching strategy that works on your entire site with only one line of code at the top of your script. The cached pages can be stored as files or as database objects. The benefits are absolutely astounding: bandwidth savings of up to 80% and screen display times increased by 8 - 10x.
        Visit the <a href="http://quickcache.worxware.com/">QuickCache website</a>.<br />
        <br />
        </li>
        <li><strong><span style="background-color: #FFFF00">QuickSkin</span></strong>. Originally authored by Philipp v. Criegern and named "SmartTemplate". The project was taken over by Manuel 'EndelWar' Dalla Lana and now by "codeworxtech". QuickSkin is one of the truly outstanding templating engines available, but has always been confused with Smarty Templating Engine. QuickSkin is even more relevant today than when it was launched. It&#39;s a small footprint with big impact on your projects. It features a built in caching technology, token based substitution, and works on the concept of HTML files as the template(s). The HTML template file can contain variable information making it one small powerful tool for your developer tool kit.
        Visit the <a href="http://quickskin.worxware.com/">QuickSkin website</a>.<br />
        <br />
        </li>
        <li><strong><span style="background-color: #FFFF00">QuickCSV Suite</span></strong>. We launched a great product suite to help manage CSV files &ndash; both getting CSV files uploaded to a MySQL table and/or getting an existing MySQL table downloaded to a CSV file.
        For screen shots and more information, please <a href="http://quickcsv.worxware.com/ss.html" target="_blank">click here</a>.We've been using QuickCSV Suite for some time to automate our CSV upload/download tasks. All I can say is that it is one of the most impressive feature sets that automates handling CSV files quite easily.<br />
        </li>
      </ul>
      <p>We're committed to PHP and to the Open Source community.</p>
      <p>Opportunities with <strong>Worx International Inc.</strong>:</p>
      <ul>
      <li><span style="background-color: #FFFF00">Resellers/Agents</span>: We're always interested in talking with companies that want to represent
      <strong>Worx International Inc.</strong> in their markets. We also have private label programs for our commercial products (in certain circumstances). Our <a href="http://www.worxstudio.com" target="_blank">Web Design</a> and <a href="http://www.worxhost.com" target="_blank">Web Hosting</a> is represented solely by agents and resellers.</li>
      <li>Programmers/Developers: We are usually fully staffed, however, if you would like to be considered for a career with
      <strong>Worx International Inc.</strong>, we would be pleased to hear from you.<br />
      A few things to note:<br />
      <ul>
        <li>experience level does not matter: from fresh out of college to multi-year experience - it&#39;s your
        creative mind and a positive attitude we want</li>
        <li>if you contact us looking for employment, include a cover letter, indicate what type of work/career you are looking for and expected compensation</li>
        <li>if you are representing someone else looking for work, do not contact us. We have an exclusive relationship with a recruiting partner already and not interested in altering the arrangement. We will not hire your candidate under any circumstances unless they wish to approach us individually.</li>
        <li>any contact that ignores any of these points will be discarded</li>
      </ul></li>
      <li>Affiliates/Partnerships: We are interested in partnering with other firms who are leaders in their field. We clearly understand that successful companies are built on successful relationships in all industries world-wide. We currently have innovative relationships throughout the world that are mutually beneficial. Drop us a line and let&#39;s talk.</li>
      </ul>
      Regards,<br />
      Andy Prevost (aka, codeworxtech)<br />
      <a href="mailto:codeworxtech@users.sourceforge.net">codeworxtech@users.sourceforge.net</a><br />
      <br />
      We now also offer website design. hosting, and remote forms processing. Visit <a href="http://www.worxstudio.com/" target="_blank">WorxStudio.com</a> for more information.<br />
    </td>
  </tr>
</table>
</div>
<?php
echo '</div>';

//$pgArr['button'] = '<a href="index.php?pg=lists&proc=add" class="button"><img border="0" src="appimgs/add.png" title="' . $PHPML_LANG["add_new_list"] . '"></a>';
$pgArr['caption'] = 'About Worx International Inc.';
$pgArr['contents'] = ob_get_contents();
//$pgArr['help']     = "Manage your lists. You have the ability to:<br />
//  Add<br />
//  Delete<br />";
ob_end_clean();
echo getSkin ($pgArr);

?>
